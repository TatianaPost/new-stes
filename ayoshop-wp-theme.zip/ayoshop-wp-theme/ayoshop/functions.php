<?php

/** Ayo Child Theme Engine */
require_once( get_stylesheet_directory() . '/lib/init.php' );

/** You can add your custom function here */